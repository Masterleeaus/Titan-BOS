<?php

return [
    'name' => 'BudgetAllocationAprovalModule',
];
