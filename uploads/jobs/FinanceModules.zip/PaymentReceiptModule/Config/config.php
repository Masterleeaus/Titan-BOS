<?php

return [
    'name' => 'PaymentReceiptModule',
];
