<?php

return [
    'name' => 'Contractor',
];
