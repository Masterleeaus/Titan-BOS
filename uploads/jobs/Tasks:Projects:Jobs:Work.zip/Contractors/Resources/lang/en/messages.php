<?php

return [
    'title' => 'Contractors',
];
