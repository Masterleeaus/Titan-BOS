// Contractor module bootstrap
