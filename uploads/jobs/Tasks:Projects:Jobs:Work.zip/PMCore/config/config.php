<?php

return [
    'name' => 'PMCore',
];
